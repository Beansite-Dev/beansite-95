try {


document.getElementById('bgImg').addEventListener('input', (e) => {
    if (document.getElementById('bgIMode').value != "none") {
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onloadend = function(){
            document.body.style.backgroundImage = "url(" + reader.result + ")";
        }
        if(file){
            reader.readAsDataURL(file);
        }
    }
})
document.getElementById('bgClr').addEventListener('input', (e) => {
    document.body.style.background = e.target.value;
})
document.getElementById('bgIMode').addEventListener('change', (e) => {
    e.preventDefault();
    if (e.target.value != "none") document.body.style.backgroundSize = e.target.value;
    else document.body.style.backgroundImage = "none";
})
document.getElementById('tbClr').addEventListener('input', (e) => {
    document.querySelector(":root").style.setProperty('--tb-clr', e.target.value)
})
document.getElementById('bgRepeat').addEventListener('change', (e) => {
    e.preventDefault();
    document.body.style.backgroundRepeat = e.target.value;
})


document.getElementById('tbStyle').addEventListener('change', (e) => {
    e.preventDefault();
    var navs = document.getElementsByClassName('winnav'); // get all elements
	for(var i = 0; i < navs.length; i++){
		navs[i].style.background = e.target.value;
        // alert(`changed ${navs[i].id}'s bg to ${e.target.value}`)
	}
})

}
catch (e) {
  alert(`Error:\n${e.stack}\n${e.name}\n${e.message}`);
}